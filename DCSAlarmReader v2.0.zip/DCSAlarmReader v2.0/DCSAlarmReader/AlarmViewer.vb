﻿Public Class AlarmViewer
    Private WithEvents DCSAlarmTimer As New System.Windows.Forms.Timer()
    Private AlarmFetchInterval As Integer = 2 * 60              '15 sec            '2 min
    Private ReadTimeString As String = Nothing
    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        With DCSAlarmTimer
            .Enabled = True
            .Interval = 1000 * AlarmFetchInterval
        End With
        IPrealm = Get_IP_realm().Substring(0, 3)
        'Dim AlarmString As String = "Select TOP 1 AlarmTime FROM " & GetAlarmTableName("SL910") & vbCrLf & _
        '                            "WHERE SUBSTRING(AlarmTag,1,1) ='A' " & vbCrLf & _
        '                            "ORDER BY AlarmTime DESC"
        Dim AlarmString As String = "Select TOP 1 AlarmTime FROM " & GetAlarmTableName("SSP123") & vbCrLf & _
                                    "WHERE (AlarmTag IN ('IC2868', 'MA1831', 'MA2831', 'TI1831', 'TI2831')) " & vbCrLf & _
                                    "ORDER BY AlarmTime DESC"
        Dim LastAlarmData As DataTable = POPULATE(GetConnectionString("SSP123"), AlarmString)
        Dim LastReadAlarmTime As String = Format(Date.Parse(LastAlarmData.Rows(0)("AlarmTime")).AddMinutes(-10), "yyyy/MM/dd HH:mm:ss")
        Dim AlarmTimerString As String = Format(Now.AddSeconds(-AlarmFetchInterval), "yyyy/MM/dd HH:mm:ss")
        If LastReadAlarmTime < AlarmTimerString Then ReadTimeString = LastReadAlarmTime Else ReadTimeString = AlarmTimerString
        'ReadTimeString = "2021/11/03 10:30:00"
        FetchAlarm(ReadTimeString)
        With Me
            .ShowInTaskbar = False
            .WindowState = FormWindowState.Minimized
            .Hide()
        End With
    End Sub
    Private Sub TimerTick() Handles DCSAlarmTimer.Tick
        ReadTimeString = Format(Now.AddSeconds(-AlarmFetchInterval), "yyyy/MM/dd HH:mm:ss")
        FetchAlarm(ReadTimeString)
    End Sub
    Private Sub FetchAlarm(ByVal ThisTimeString As String)
        'ReadTimeString = "2016/08/23 23:20:00"
        Dim UnReadAlarmLogList As List(Of String) = GetUnReadAlarmLog(ReadTimeString)
        For Each AlarmFiles As String In UnReadAlarmLogList
            Dim UnReadAlarmsList As List(Of String) = Get_UnRead_Alarm_Captures(AlarmFiles, ReadTimeString)
            For Each UnExtractedAlarm As String In UnReadAlarmsList
                Dim NewAlarm As Alarm = ExtractReadAlarm(UnExtractedAlarm)
                If NewAlarm IsNot Nothing Then
                    With NewAlarm
                        Dim AlarmExists As Boolean = Get_History_From_SQL(.AlarmMachine, .AlarmType, .AlarmTime, .AlarmTag, .AlarmText, .AlarmPV)
                        If AlarmExists = False Then
                            AddAlarmMsg(NewAlarm)
                        End If
                    End With
                End If
            Next
        Next
    End Sub
    'Private Sub AlarmViewer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    '    With Me
    '        .ShowInTaskbar = False
    '        .WindowState = FormWindowState.Minimized
    '        .Hide()
    '    End With
    'End Sub
End Class
