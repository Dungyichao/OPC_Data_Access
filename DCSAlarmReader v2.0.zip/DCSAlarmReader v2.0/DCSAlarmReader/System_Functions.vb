﻿Imports System.IO
Imports System.Collections.Generic
Imports System.Text.RegularExpressions

Module System_Functions
    Public IPrealm As String
    Public AlarmLogName As String = "HISHIST"
    'Public SourceLogFolder As String = "D:\CENTUMVP\Log\" & AlarmLogName
    Public SourceLogFolder As String = "C:\EXA\CENTUM\Log\HISHIST\"
    Public YokogawaLogExt As String = ".log"



    Public Function Get_IP_realm() As String
        Dim IPDomain As String() = {"172", "192"}
        Dim IPAddress As String = ""
        Dim MyIp As Object = System.Net.Dns.GetHostAddresses(Environment.MachineName)
        Dim FoundRealmBool As Boolean = False
        For DomainIdx As Integer = IPDomain.GetLowerBound(0) To IPDomain.GetUpperBound(0)
            Dim I As Integer
            For Each IP As Net.IPAddress In MyIp
                IPAddress = MyIp(I).ToString
                FoundRealmBool = Len(IPAddress) > 10 And Strings.Left(IPAddress, 3) = IPDomain(DomainIdx)
                If FoundRealmBool Then Exit For
                I = I + 1
            Next
            If FoundRealmBool Then Exit For
        Next
        Return IPAddress
    End Function
    Public Function POPULATE(ByVal ThisConnectionString As String, ByVal ThisSQLCommandString As String) As DataTable
        Dim Table As New DataTable
        Try
            Using Connection As New SqlClient.SqlConnection(ThisConnectionString), _
                MyCommand As New SqlClient.SqlCommand(ThisSQLCommandString, Connection)
                Dim MyAdapter As New SqlClient.SqlDataAdapter
                MyAdapter.SelectCommand = MyCommand
                Connection.Open()
                Table.Locale = System.Globalization.CultureInfo.InvariantCulture
                MyAdapter.Fill(Table)
            End Using
        Catch ex As Exception
        End Try
        Return Table
    End Function
    Public Function POPULATEWithRowsAffected(ByVal ThisConnectionString As String, ByVal ThisSQLCommandString As String) As Integer
        Try
            Using Connection As New SqlClient.SqlConnection(ThisConnectionString), _
            MyCommand As New SqlClient.SqlCommand(ThisSQLCommandString, Connection)
                Connection.Open()
                Dim MyAdapter As New SqlClient.SqlDataAdapter
                MyAdapter.SelectCommand = MyCommand
                Return MyCommand.ExecuteNonQuery
            End Using
        Catch ex As Exception
        End Try
        
    End Function
    Public Function Get_History_From_SQL(ByVal ThisAlarmMachine As String, ByVal ThisAlarmType As String, ByVal ThisAlarmTime As String, _
                                        ByVal ThisAlarmTag As String, ByVal ThisAlarmText As String, ByVal ThisAlarmPV As String) As Boolean

        Dim ThisDestinationTableName As String = GetAlarmTableName(ThisAlarmMachine)
        Dim HistoryString As String = "SELECT * FROM " & ThisDestinationTableName & " WHERE " & _
                                        "(AlarmType = '" & Trim(ThisAlarmType) & "') AND " & _
                                        "(AlarmTime = '" & Trim(ThisAlarmTime) & "') AND " & _
                                        "(AlarmTag = '" & Trim(ThisAlarmTag) & "') AND " & _
                                        "(AlarmText = '" & Trim(ThisAlarmText) & "') AND " & _
                                        "(AlarmPV = '" & Trim(ThisAlarmPV) & "') "
        Dim ThisTargetSQLConnectionString As String = GetConnectionString(ThisAlarmMachine)
        Dim AlarmData As DataTable = POPULATE(ThisTargetSQLConnectionString, HistoryString)
        Dim AlarmExist As Boolean = (AlarmData.Rows.Count >= 1)
        Return AlarmExist
    End Function

    Public Function GetAlarmTableName(ByVal AlarmMachine As String) As String
        Select Case AlarmMachine
            Case "SL1", "FCS0101", "FCS0102", "FCS0103"
                Return "AlarmSL1"
            Case "SL2", "FCS0104", "FCS0105", "FCS0106"
                Return "AlarmSL2"
            Case "SL3", "FCS0107", "FCS0108"
                Return "AlarmSL3"
            Case "SL4", "FCS0109", "FCS0110"
                Return "AlarmSL4"
            Case "SL56"
                Return "AlarmSL56"
            Case "SL78"
                Return "AlarmSL78"
            Case "SL11"
                Return "AlarmSL11"
            Case "SL12"
                Return "AlarmSL12"
            Case "SL910", "FCS0214", "FCS0215"
                Return "AlarmSL910"
            Case "SSP123", "FCS0206"
                Return "AlarmSPP123"
        End Select
        Return Nothing
    End Function
    Public Function GetConnectionString(ByVal AlarmMachine As String) As String
        Dim DataSource As String = Nothing
        Select Case IPrealm
            Case "192"
                Select Case AlarmMachine
                    Case "SL1", "FCS0101", "FCS0102", "FCS0103"
                        DataSource = "192.168.20.60"
                    Case "SL2", "FCS0104", "FCS0105", "FCS0106"
                        DataSource = "192.168.20.60"
                    Case "SL3", "SL4", "FCS0107", "FCS0108", "FCS0109", "FCS0110"
                        DataSource = "192.168.20.60"
                    Case "SL56", "SL910"
                        DataSource = "192.168.0.250"
                    Case "SL78"
                        DataSource = "192.168.20.50"
                    Case "SL11", "SL12", "SSP123"
                        DataSource = "192.168.20.50"
                End Select
            Case ("172")
                Select Case AlarmMachine
                    Case "SL1", "FCS0101", "FCS0102", "FCS0103"
                        DataSource = "172.16.218.2"
                    Case "SL2", "FCS0104", "FCS0105", "FCS0106"
                        DataSource = "172.16.218.2"
                    Case "SL3", "SL4", "FCS0107", "FCS0108", "FCS0109", "FCS0110"
                        DataSource = "172.16.218.4"
                    Case "SL56", "SL910", "FCS0214", "FCS0215"
                        DataSource = "172.16.218.5"
                    Case "SL78"
                        DataSource = "172.16.218.7"
                    Case "SL11", "SL12", "SSP123", "FCS0206"
                        DataSource = "172.16.216.234"
                End Select
        End Select
        Return "Data Source = " & DataSource & "; Initial Catalog= DCS; UID= sa; PWD=;"
    End Function
    Public Function GetUnReadAlarmLog(ByVal LastReadTimeString As String) As List(Of String)
        Dim SourceDirectory As New DirectoryInfo(SourceLogFolder)
        Dim AlarmLogList As New List(Of String)
        For Each AlarmTextFiles As FileInfo In SourceDirectory.GetFiles
            Dim ExtBool As Boolean = (AlarmTextFiles.Extension = YokogawaLogExt)
            'Dim WriteTimeBool As Boolean = (Format(AlarmTextFiles.LastWriteTime, "yyyy/MM/dd HH:mm:ss") >= LastReadTimeString)
            Dim WriteTimeBool As Boolean = (Format(AlarmTextFiles.LastWriteTime, "yyyy/MM/dd") >= LastReadTimeString.Substring(0, 10))
            If WriteTimeBool And ExtBool Then
                AlarmLogList.Add(AlarmTextFiles.Name)
            End If
        Next
        Return AlarmLogList
    End Function
    Public Function Get_UnRead_Alarm_Captures(ByVal CaptureAlarmFilename As String, ByVal ThisDateString As String) As List(Of String)
        'Dim ReadLogDate As String = Strings.Replace(Strings.Left(ThisDateString, 10), "/", "")
        'Dim AlarmLognameString As String = AlarmLogName & "-" & ReadLogDate
        'Dim LastLogIndex As String = Strings.Replace(Strings.Replace(CaptureAlarmFilename, AlarmLogName, ""), "-" & ReadLogDate & ".txt", "")
        '=========================================================================================
        Dim UnReadAlarm As New List(Of String)
        Dim ThisFileStream As New FileStream(SourceLogFolder & "\" & CaptureAlarmFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
        Dim StreamR As New StreamReader(ThisFileStream, System.Text.Encoding.Default)
        'StreamR.BaseStream.CanSeek
        'StreamR.BaseStream.Seek()
        Do While StreamR.Peek() >= 0
            Dim StrContent As String = StreamR.ReadLine()
            Dim StringReaderCheck As Boolean = (StrContent.Length >= 0) And Strings.Left(StrContent, 1) <> "?"
            If StringReaderCheck Then
                Dim AlarmTimeBool As Boolean = (Strings.Left(StrContent, 19) > ThisDateString)
                If AlarmTimeBool Then
                    UnReadAlarm.Add(StrContent)
                End If
            End If
        Loop
        Return UnReadAlarm
    End Function
    Public Function FindStrIndex(ByVal FromThisString As String, ByVal nthOccurrence As Integer, Optional ByVal TargetString As String = ",") As Integer
        Dim CurrentPosIndex As Integer = 1
        Dim FoundIndex As Integer = 0
        Try
            For Recur As Integer = 1 To nthOccurrence
                FoundIndex = InStr(CurrentPosIndex, FromThisString, TargetString)
                If FoundIndex > 0 Then CurrentPosIndex = FoundIndex + 1
            Next
            If FoundIndex > 0 Then Return FoundIndex + 1
        Catch ex As Exception

        End Try
        Return -1
    End Function
    Public Function ExtractReadAlarm(ByVal ThisStringContent As String) As Alarm
        Dim ExceptionsCode As String() = {"0482", "0330", "0231", "0236", "0082", "0607", "0646", "0510", "0502", "0390", "0394", "0304", "0303", "1605"}
        Dim AlarmMode As String = Strings.Mid(ThisStringContent, FindStrIndex(ThisStringContent, 2, ","), 4)
        Debug.Print(Now & " Before=" & ThisStringContent)
        If Not ExceptionsCode.Contains(AlarmMode) Then
            'Debug.Print(Now & " After=" & ThisStringContent)
            Dim StrIndex As Integer = InStrRev(ThisStringContent, ",") + 1
            Dim PVIndex As Integer = If(FindStrIndex(ThisStringContent, 1, "=") < 0, Len(ThisStringContent), FindStrIndex(ThisStringContent, 1, "="))
            Dim oldIndex As Integer = InStrRev(ThisStringContent, "=")
            Dim ThisAlarmOld As String = Nothing
            Dim OldBool As Boolean = False
            If oldIndex <> 0 Then OldBool = (Strings.Mid(ThisStringContent, oldIndex - 3, 3) = "old")
            Dim PVBool As Boolean = (PVIndex - 1 < oldIndex)
            If PVBool And OldBool Then              'there 2 equals signs
                PVIndex = FindStrIndex(ThisStringContent, 1, "=") - 5
                oldIndex = FindStrIndex(ThisStringContent, 2, "=")
                ThisAlarmOld = Strings.Mid(ThisStringContent, oldIndex, 8)
            ElseIf PVBool And Not OldBool Then         'There is Only PV =
                PVIndex = StrIndex + 13 + 25
            ElseIf OldBool And Not PVBool Then         'There is only OLD=
                PVIndex = oldIndex - 8
                ThisAlarmOld = Strings.Mid(ThisStringContent, oldIndex + 1, 6)
            Else         'Threre is NO equals sign
                'PVIndex = StrIndex + 13 + 25
                PVIndex = If(StrIndex + 13 + 25 > Len(ThisStringContent), Len(ThisStringContent), StrIndex + 13 + 25)
            End If
            Dim SearchLength As Integer = Math.Max(1, Len(ThisStringContent) - PVIndex + 1)
            Dim PVString As String = Strings.Mid(ThisStringContent, PVIndex, SearchLength)
            Debug.Print(Now + " PVINDEX=" + PVIndex.ToString + " PVString" + PVString)
            PVString = Strings.Replace(PVString, "[ ONUSER@HIS0160 ]", "")
            PVString = Strings.Replace(PVString, "[ ONUSER@HIS0161 ]", "")
            PVString = Strings.Replace(PVString, "[ ONUSER@HIS0162 ]", "")
            PVString = Strings.Replace(PVString, "[ ONUSER@HIS0163 ]", "")
            Dim ThisAlarmMachine As String = Strings.Mid(ThisStringContent, FindStrIndex(ThisStringContent, 6, ","), 7)
            Dim ThisAlarmType As String = Strings.Mid(ThisStringContent, FindStrIndex(ThisStringContent, 2), 4)
            Dim ThisAlarmTime As String = Strings.Mid(ThisStringContent, 1, 19)
            Dim ThisAlarmTag As String = Strings.Mid(Strings.Mid(ThisStringContent, StrIndex, 13), 1, 12)
            Dim ThisAlarmText As String = Strings.Mid(ThisStringContent, StrIndex + 13, 25)
            Dim ThisAlarmPV As String = Strings.Mid(ThisStringContent, PVIndex, 4)
            Dim ThisAlarmValue As String = Strings.Mid(ThisStringContent, PVIndex + 5, 8)
            Dim ThisAlarmUnit As String = Strings.Mid(ThisStringContent, PVIndex + 13, 5)
            Dim UnitStringLength As Integer = 5
            'Debug.Print(Now & " PVString.length=" & PVString.Length.ToString)
            If PVString.Length >= 15 Then
                Select Case Len(PVString)
                    Case 15
                        UnitStringLength = 5
                    Case 53 - 18
                        UnitStringLength = 9
                    Case 28, 30
                        UnitStringLength = 5
                    Case 24, 25, 26, 32, 34
                        UnitStringLength = 9
                    Case Else
                        UnitStringLength = 5
                End Select
                ThisAlarmUnit = Strings.Mid(ThisStringContent, PVIndex + 13, UnitStringLength)
            Else
                If (PVString.Length = 2 Or PVString.Length = 3) Then
                    UnitStringLength = 1
                Else
                    Return Nothing
                End If
            End If
            Dim ThisAlarmStatus As String = Strings.Mid(ThisStringContent, PVIndex + 13 + UnitStringLength, 5)
            Dim ThisAlarmRecover As String = Strings.Mid(ThisStringContent, PVIndex + 13 + UnitStringLength + 5, 7).ToUpper
            Dim ThisAlarmStar As String = "***"
            If ThisAlarmRecover.ToUpper = "RECOVER" Or ThisAlarmType = "1601" Then ThisAlarmStar = ""
            If OldBool Then                'Handles AUT/MAN
                ThisAlarmStatus = Strings.Mid(ThisStringContent, oldIndex - 4, 3)
                ThisAlarmRecover = Nothing
                If Trim(ThisAlarmPV) = "MAN" Or Trim(ThisAlarmPV) = "AUT" Or Trim(ThisAlarmPV) = "CAS" Then
                    ThisAlarmStatus = ThisAlarmPV
                    ThisAlarmValue = Nothing
                    ThisAlarmUnit = Nothing
                End If
            Else
                If ThisAlarmPV = "MAN" Or ThisAlarmPV = "AUT" Or ThisAlarmPV = "CAS" Then
                    ThisAlarmStatus = ThisAlarmPV
                    ThisAlarmValue = Nothing
                    ThisAlarmUnit = Nothing
                    ThisAlarmRecover = Nothing
                End If
            End If
            If Trim(ThisAlarmPV) = "NR" And ThisAlarmType = "1206" Then ThisAlarmRecover = "RECOVER"
            Dim ThisAlarm As New Alarm With {.AlarmMachine = ThisAlarmMachine, _
                                                        .AlarmStar = ThisAlarmStar, .AlarmType = ThisAlarmType, .AlarmTime = ThisAlarmTime, _
                                                        .AlarmTag = ThisAlarmTag, .AlarmText = ThisAlarmText, .AlarmPV = ThisAlarmPV, _
                                                        .AlarmValue = ThisAlarmValue, .AlarmUnit = ThisAlarmUnit, .AlarmStatus = ThisAlarmStatus, _
                                                        .AlarmRecover = ThisAlarmRecover, _
                                                        .AlarmOld = ThisAlarmOld}
            Return ThisAlarm
        End If
        Return Nothing
    End Function

    Public Function AddAlarmMsg(ByVal ThisNewAlarm As Alarm) As Integer
        With ThisNewAlarm
            Dim MyConnectionString As String = GetConnectionString(.AlarmMachine)
            Dim TargetAlarmTableName As String = GetAlarmTableName(.AlarmMachine)
            Dim InsertString As String = "INSERT INTO " & TargetAlarmTableName & " VALUES('" & _
                                                        .AlarmStar & "', '" & _
                                                        .AlarmType & "', '" & _
                                                        .AlarmTime & "', '" & _
                                                        Trim(.AlarmTag) & "', '" & _
                                                        Trim(.AlarmText) & "', '" & _
                                                        Trim(.AlarmPV) & "', '" & _
                                                        Trim(.AlarmValue) & "', '" & _
                                                        Trim(.AlarmUnit) & "', '" & _
                                                        Trim(.AlarmStatus) & "', '" & _
                                                        Trim(.AlarmRecover) & "', '" & _
                                                        Trim(.AlarmOld) & "') "                                                        
            Dim InsertSuccess As Integer = POPULATEWithRowsAffected(MyConnectionString, InsertString)
            Return InsertSuccess
        End With
    End Function
    Public Class Alarm
        Private _AlarmStar, _AlarmTime, _AlarmTag, _AlarmText, _AlarmPV, _AlarmUnit, _AlarmStatus, _AlarmRecover, _AlarmMachine, _AlarmOld As String
        Private _AlarmType As String
        Private _AlarmValue As String

        Property AlarmMachine() As String
            Get
                Return _AlarmMachine
            End Get
            Set(ByVal value As String)
                _AlarmMachine = value
            End Set
        End Property
        Property AlarmStar() As String
            Get
                Return _AlarmStar
            End Get
            Set(ByVal value As String)
                _AlarmStar = value
            End Set
        End Property
        Property AlarmType() As String
            Get
                Return _AlarmType
            End Get
            Set(ByVal value As String)
                _AlarmType = value
            End Set
        End Property
        Property AlarmTime() As String
            Get
                Return _AlarmTime
            End Get
            Set(ByVal value As String)
                _AlarmTime = value
            End Set
        End Property
        Property AlarmTag() As String
            Get
                Return _AlarmTag
            End Get
            Set(ByVal value As String)
                _AlarmTag = value
            End Set
        End Property
        Property AlarmText() As String
            Get
                Return _AlarmText
            End Get
            Set(ByVal value As String)
                _AlarmText = value
            End Set
        End Property
        Property AlarmPV() As String
            Get
                Return _AlarmPV
            End Get
            Set(ByVal value As String)
                _AlarmPV = value
            End Set
        End Property
        Property AlarmValue() As String
            Get
                Return _AlarmValue
            End Get
            Set(ByVal value As String)
                _AlarmValue = value
            End Set
        End Property
        Property AlarmUnit() As String
            Get
                Return _AlarmUnit
            End Get
            Set(ByVal value As String)
                _AlarmUnit = value
            End Set
        End Property
        Property AlarmStatus() As String
            Get
                Return _AlarmStatus
            End Get
            Set(ByVal value As String)
                _AlarmStatus = value
            End Set
        End Property
        Property AlarmRecover() As String
            Get
                Return _AlarmRecover
            End Get
            Set(ByVal value As String)
                _AlarmRecover = value
            End Set
        End Property
        Property AlarmOld() As String
            Get
                Return _AlarmOld
            End Get
            Set(ByVal value As String)
                _AlarmOld = value
            End Set
        End Property
    End Class

End Module
